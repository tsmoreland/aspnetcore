kubectl delete deployment catalog
kubectl delete deployment frontend
kubectl delete deployment ordering
kubectl delete deployment sqlserver
